const crypto = require("node:crypto");

const {
  assertMethod,
  getBaseUrl,
  sendJson
} = require("../../_lib/soc-auth");

const CANONICAL_GOOGLE_REDIRECT_URI = "https://mk-git-main-tawhidurrahman13s-projects.vercel.app/api/auth/google/callback";

function maskClientId(clientId) {
  if (!clientId) return "";
  const [prefix, domain] = clientId.split(".");
  return `${prefix.slice(0, 10)}...${domain || ""}`;
}

function secretFingerprint(secret) {
  if (!secret) return "";
  return crypto.createHash("sha256").update(secret).digest("hex").slice(0, 12);
}

function looksLikeSupabaseServerKey(key) {
  if (!key) return false;
  if (key.startsWith("sb_secret_")) return true;

  try {
    const payload = JSON.parse(Buffer.from(key.split(".")[1] || "", "base64url").toString("utf8"));
    return payload.role === "service_role";
  } catch {
    return false;
  }
}

module.exports = async function googleDiagnostics(req, res) {
  if (!assertMethod(req, res, "GET")) return;

  const clientId = String(process.env.GOOGLE_CLIENT_ID || "").trim();
  const clientSecretRaw = String(process.env.GOOGLE_CLIENT_SECRET || "");
  const clientSecret = clientSecretRaw.trim();
  const redirectUri = String(process.env.GOOGLE_REDIRECT_URI || "").trim() || CANONICAL_GOOGLE_REDIRECT_URI;
  const authSecret = String(process.env.AUTH_SECRET || process.env.SESSION_SECRET || "").trim();
  const supabaseUrl = String(process.env.SUPABASE_URL || "").trim();
  const supabaseServiceKey = String(process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_KEY || "").trim();
  const smtpHostRaw = String(process.env.SMTP_HOST || "");
  const smtpHost = smtpHostRaw.trim();
  const smtpPort = String(process.env.SMTP_PORT || "").trim();
  const smtpUser = String(process.env.SMTP_USER || "").trim();
  const smtpPass = String(process.env.SMTP_PASS || "").trim();
  const emailFrom = String(process.env.EMAIL_FROM || "").trim();
  const requestBaseUrl = getBaseUrl(req);

  const checks = [
    {
      name: "GOOGLE_CLIENT_ID is present",
      ok: Boolean(clientId),
      fix: "Add GOOGLE_CLIENT_ID in Vercel Environment Variables."
    },
    {
      name: "GOOGLE_CLIENT_ID looks like a web OAuth client ID",
      ok: clientId.endsWith(".apps.googleusercontent.com"),
      fix: "Copy the Client ID from Google Auth Platform -> Clients -> your Web application client."
    },
    {
      name: "GOOGLE_CLIENT_SECRET is present",
      ok: Boolean(clientSecret),
      fix: "Add GOOGLE_CLIENT_SECRET in Vercel Environment Variables."
    },
    {
      name: "GOOGLE_CLIENT_SECRET is not accidentally the Client ID",
      ok: Boolean(clientSecret) && !clientSecret.includes(".apps.googleusercontent.com") && clientSecret !== clientId,
      fix: "Replace GOOGLE_CLIENT_SECRET with the Client secret from the same Google OAuth client, not the Client ID."
    },
    {
      name: "GOOGLE_CLIENT_SECRET has no pasted key name or quotes",
      ok: Boolean(clientSecret)
        && !clientSecret.includes("GOOGLE_CLIENT_SECRET")
        && !/^['"]|['"]$/.test(clientSecret),
      fix: "Paste only the secret value, with no GOOGLE_CLIENT_SECRET= prefix and no quote marks."
    },
    {
      name: "GOOGLE_REDIRECT_URI points to the callback route",
      ok: /^https:\/\/[^ ]+\/api\/auth\/google\/callback$/.test(redirectUri),
      fix: "Set GOOGLE_REDIRECT_URI to https://mk-git-main-tawhidurrahman13s-projects.vercel.app/api/auth/google/callback."
    },
    {
      name: "AUTH_SECRET is present",
      ok: authSecret.length >= 24,
      fix: "Add a long AUTH_SECRET in Vercel and redeploy."
    },
    {
      name: "SUPABASE_URL is present",
      ok: /^https:\/\/[^ ]+\.supabase\.co$/.test(supabaseUrl),
      fix: "Add SUPABASE_URL from Supabase Project Settings -> API Keys -> Project URL."
    },
    {
      name: "SUPABASE_SERVICE_ROLE_KEY is present",
      ok: Boolean(supabaseServiceKey),
      fix: "Add SUPABASE_SERVICE_ROLE_KEY in Vercel. Use a Supabase secret key or legacy service_role key, not the anon key."
    },
    {
      name: "SUPABASE_SERVICE_ROLE_KEY looks server-side",
      ok: looksLikeSupabaseServerKey(supabaseServiceKey),
      fix: "Copy the Supabase secret key or legacy service_role key. Do not use the anon/public key."
    },
    {
      name: "SMTP_HOST is exactly smtp.gmail.com",
      ok: smtpHost === "smtp.gmail.com" && smtpHostRaw === smtpHost,
      fix: "Set SMTP_HOST to smtp.gmail.com exactly, with no spaces or hidden new lines."
    },
    {
      name: "SMTP_PORT is 465",
      ok: smtpPort === "465",
      fix: "Set SMTP_PORT to 465."
    },
    {
      name: "SMTP_USER is present",
      ok: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(smtpUser),
      fix: "Set SMTP_USER to your Gmail address."
    },
    {
      name: "SMTP_PASS is present",
      ok: Boolean(smtpPass),
      fix: "Set SMTP_PASS to your Gmail App Password, not your normal Gmail password."
    },
    {
      name: "EMAIL_FROM is present",
      ok: Boolean(emailFrom) && emailFrom.includes("@"),
      fix: "Set EMAIL_FROM to SOC Bootcamp <your_gmail@gmail.com>."
    }
  ];

  sendJson(res, 200, {
    summary: checks.every((check) => check.ok) ? "basic_checks_passed" : "needs_attention",
    deployedClientId: maskClientId(clientId),
    deployedClientIdFull: clientId,
    redirectUri,
    requestBaseUrl,
    clientSecretConfigured: Boolean(clientSecret),
    clientSecretLength: clientSecret.length,
    clientSecretFingerprint: secretFingerprint(clientSecret),
    supabaseUrlConfigured: Boolean(supabaseUrl),
    supabaseServiceKeyConfigured: Boolean(supabaseServiceKey),
    supabaseServiceKeyFingerprint: secretFingerprint(supabaseServiceKey),
    smtpHost,
    smtpHostHasHiddenWhitespace: smtpHostRaw !== smtpHost,
    smtpUserConfigured: Boolean(smtpUser),
    smtpPassConfigured: Boolean(smtpPass),
    smtpPassLength: smtpPass.length,
    checks
  });
};
